FILES:

INDEX.PHP
![image](https://github.com/user-attachments/assets/5d608923-f303-4f26-bc34-b7fe2d6535bc)


REGISTER.PHP
![image](https://github.com/user-attachments/assets/6baab530-fed1-41af-a337-757a3b27bb94)

LOGIN.PHP
![image](https://github.com/user-attachments/assets/2e4196a5-a3de-4586-bed7-0692636bf5f1)

username: reverente
password: Reverente1_

homepage.php
![image](https://github.com/user-attachments/assets/5d8caf04-4bea-4d0b-8b39-3de6a20ab947)
![image](https://github.com/user-attachments/assets/3d1cde13-52d0-434f-9c51-d953ea5289ab)

aboutus.php
![image](https://github.com/user-attachments/assets/6cede35b-703f-4476-886d-09651924c0e8)

products.php
![image](https://github.com/user-attachments/assets/23aa6045-5292-4a6e-b097-849b0592113b)
![image](https://github.com/user-attachments/assets/32906ab6-982a-4d3a-a558-d5adb3d985f6)
![image](https://github.com/user-attachments/assets/ed0f442c-839c-4d13-8274-8a75759c6a73)
![image](https://github.com/user-attachments/assets/2abe82ae-f57b-48ab-9e21-2e1f0a9f33a9)
![image](https://github.com/user-attachments/assets/cc7ac56a-928c-4c6b-97de-877db2c46a6a)
![image](https://github.com/user-attachments/assets/da0e3c2d-25d3-4790-8495-17006187c904)
![image](https://github.com/user-attachments/assets/df0f0d5d-c8b2-45d3-9390-3b206fb116a5)


cart.php
![image](https://github.com/user-attachments/assets/b4727010-ffcb-432d-abdd-51c50b0bb018)

WITH ITEMS:
![image](https://github.com/user-attachments/assets/62c865f5-9fa9-4dea-9680-32b90aeac908)

checkout.php
![image](https://github.com/user-attachments/assets/477b3799-75f9-4131-afaf-0b0267ad5c36)
![image](https://github.com/user-attachments/assets/a6f7531c-9bc1-4735-a903-a5a86235e4e1)
![image](https://github.com/user-attachments/assets/c5346909-da4d-4f5a-8fe4-ded9467960b5)

thankyou.php (after placing an order)
![image](https://github.com/user-attachments/assets/f76f22c5-d94f-4074-a34e-9e724971c47f)

creators.php
![image](https://github.com/user-attachments/assets/7d034253-ba7a-4ca0-9dd4-eaf871a73301)








